#!/bin/bash
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 🔧 기존 프로젝트에 바이브 코딩 v5 적용
# Context Engineering + Vibe Coding 통합
# 사용법: 기존 프로젝트 폴더 안에서 실행
#   cd ~/내프로젝트
#   bash ~/vibe-scaffold/scripts/apply-to-existing.sh
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

set -e

SCAFFOLD_DIR="$(cd "$(dirname "$0")/.." && pwd)"

echo ""
echo "🔧 기존 프로젝트에 바이브 코딩 v5 적용"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📂 프로젝트: $(pwd)"
echo "⚠️ 기존 코드는 건드리지 않습니다."
echo ""
read -p "진행할까요? (Enter = 예) "

# ============================================================
# Step 1: AI 팀 + 컨텍스트 엔지니어링 설정
# ============================================================
echo ""
echo "🤖 [1/2] AI 팀 + 컨텍스트 엔지니어링 설정..."

mkdir -p .claude/agents
mkdir -p .claude/rules
mkdir -p .claude/commands
mkdir -p .claude/skills/design-system
mkdir -p .github/workflows
mkdir -p docs

cp -n "$SCAFFOLD_DIR/.claude/agents/"* .claude/agents/ 2>/dev/null || true
cp -n "$SCAFFOLD_DIR/.claude/rules/"* .claude/rules/ 2>/dev/null || true
cp -n "$SCAFFOLD_DIR/.claude/commands/"* .claude/commands/ 2>/dev/null || true
cp -n "$SCAFFOLD_DIR/.claude/skills/design-system/SKILL.md" .claude/skills/design-system/ 2>/dev/null || true
cp -n "$SCAFFOLD_DIR/.claude/settings.json" .claude/ 2>/dev/null || true
cp -n "$SCAFFOLD_DIR/.claude/.gitignore" .claude/ 2>/dev/null || true
cp -n "$SCAFFOLD_DIR/.github/workflows/"* .github/workflows/ 2>/dev/null || true
cp -n "$SCAFFOLD_DIR/docs/"* docs/ 2>/dev/null || true
cp -n "$SCAFFOLD_DIR/CLAUDE.md" . 2>/dev/null || true
cp -n "$SCAFFOLD_DIR/PROGRESS.md" . 2>/dev/null || true
cp -n "$SCAFFOLD_DIR/plan.md" . 2>/dev/null || true
cp -n "$SCAFFOLD_DIR/.eslintrc.json" . 2>/dev/null || true
cp -n "$SCAFFOLD_DIR/.gitleaks.toml" . 2>/dev/null || true

# ============================================================
# Step 2: cc-sdd 설치
# ============================================================
echo "📐 [2/2] cc-sdd 설계 도구..."
npx cc-sdd@latest --claude-agent --lang ko 2>/dev/null || echo "  ⚠️ 나중에: npx cc-sdd@latest --claude-agent --lang ko"

# ============================================================
# 완료
# ============================================================
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅ 적용 완료! (v5 — Context Engineering 포함)"
echo ""
echo "🚀 다음 단계:"
echo "  1. claude                ← Claude Code 시작"
echo "  2. Skills 설치 (Claude Code 안에서):"
echo "     npx skills add vercel-labs/agent-skills --skill frontend-design"
echo "  3. /start                ← 세션 시작 (plan.md 자동 로드)"
echo ""
echo "💡 새로 추가된 기능:"
echo "  /save   — 작업 맥락을 plan.md에 저장"
echo "  plan.md — /compact, /clear 후에도 살아남는 외부 메모리"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
