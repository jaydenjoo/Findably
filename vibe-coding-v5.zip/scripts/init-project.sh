#!/bin/bash
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 🚀 바이브 코딩 v5 프로젝트 초기화 (새 프로젝트용)
# Context Engineering + Vibe Coding 통합
# 사용법: bash scripts/init-project.sh [프로젝트명]
# 예시:  bash scripts/init-project.sh chatsio
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

set -e

PROJECT_NAME="${1:-my-project}"
SCAFFOLD_DIR="$(cd "$(dirname "$0")/.." && pwd)"
GITHUB_USER=$(gh auth status 2>&1 | grep -oP 'Logged in to github.com account \K\S+' 2>/dev/null || echo "")

echo ""
echo "🚀 바이브 코딩 v5 프로젝트 초기화"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📦 프로젝트: $PROJECT_NAME"
echo ""
read -p "진행할까요? (Enter = 예) "

# ============================================================
# Step 1: Next.js 프로젝트 생성
# ============================================================
echo ""
echo "📦 [1/6] Next.js 프로젝트 생성..."
pnpm create next-app@latest "$PROJECT_NAME" \
  --typescript --tailwind --eslint --app --src-dir \
  --import-alias "@/*" --use-pnpm --yes

cd "$PROJECT_NAME"

# ============================================================
# Step 2: 패키지 설치
# ============================================================
echo "📦 [2/6] 핵심 패키지 설치..."
pnpm add @supabase/supabase-js @supabase/ssr
pnpm add drizzle-orm zod react-hook-form @hookform/resolvers
pnpm add -D drizzle-kit prettier vitest @testing-library/react

pnpm dlx shadcn@latest init --yes
pnpm dlx shadcn@latest add button card form input label

# ============================================================
# Step 3: 폴더 구조 생성
# ============================================================
echo "📁 [3/6] 폴더 구조..."
mkdir -p src/app/\(auth\)/{sign-in,sign-up,_components}
mkdir -p src/app/\(dashboard\)/{dashboard,settings,_components}
mkdir -p src/app/\(marketing\)/{about,pricing,_components}
mkdir -p src/app/api/{webhooks/stripe,chat}
mkdir -p src/{actions,hooks,types,db/migrations}
mkdir -p src/lib/{supabase,ai,validations}
mkdir -p src/components/{layout,shared}
mkdir -p tests/{unit,integration,e2e}
mkdir -p docs scripts supabase/migrations
mkdir -p .claude/agents
mkdir -p .claude/rules
mkdir -p .claude/commands
mkdir -p .claude/skills/design-system
mkdir -p .github/workflows

# ============================================================
# Step 4: AI 팀 + 설정 + 외부 메모리 복사
# ============================================================
echo "🤖 [4/6] AI 팀 + 컨텍스트 엔지니어링 설정..."

# AI 팀 + 설정
cp -r "$SCAFFOLD_DIR/.claude/agents/"* .claude/agents/ 2>/dev/null || true
cp -r "$SCAFFOLD_DIR/.claude/rules/"* .claude/rules/ 2>/dev/null || true
cp -r "$SCAFFOLD_DIR/.claude/commands/"* .claude/commands/ 2>/dev/null || true
cp -r "$SCAFFOLD_DIR/.claude/skills/design-system/"* .claude/skills/design-system/ 2>/dev/null || true
cp "$SCAFFOLD_DIR/.claude/settings.json" .claude/ 2>/dev/null || true
cp "$SCAFFOLD_DIR/.claude/.gitignore" .claude/ 2>/dev/null || true
cp -r "$SCAFFOLD_DIR/.github/workflows/"* .github/workflows/ 2>/dev/null || true
cp "$SCAFFOLD_DIR/docs/"* docs/ 2>/dev/null || true

# 핵심 설정 파일
cp "$SCAFFOLD_DIR/CLAUDE.md" . 2>/dev/null || true
cp "$SCAFFOLD_DIR/PROGRESS.md" . 2>/dev/null || true
cp "$SCAFFOLD_DIR/plan.md" . 2>/dev/null || true
cp "$SCAFFOLD_DIR/.eslintrc.json" . 2>/dev/null || true
cp "$SCAFFOLD_DIR/.gitleaks.toml" . 2>/dev/null || true

cat > .gitignore << 'EOF'
node_modules/
.next/
out/
build/
dist/
.env
.env.local
.env*.local
npm-debug.log*
.pnpm-debug.log*
.vscode/
.idea/
*.swp
.DS_Store
.claude/settings.local.json
supabase/.temp/
.vercel
*.tsbuildinfo
next-env.d.ts
coverage/
EOF

cat > .env.example << 'EOF'
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
ANTHROPIC_API_KEY=sk-ant-...
NEXT_PUBLIC_APP_URL=http://localhost:3000
EOF
cp .env.example .env.local

# ============================================================
# Step 5: cc-sdd 설치
# ============================================================
echo "📐 [5/6] cc-sdd 설계 도구..."
npx cc-sdd@latest --claude-agent --lang ko 2>/dev/null || echo "  ⚠️ 나중에 수동: npx cc-sdd@latest --claude-agent --lang ko"

# ============================================================
# Step 6: Git + GitHub
# ============================================================
echo "🐙 [6/6] Git + GitHub..."
git init
git add -A
git commit -m "feat: initial project scaffold (vibe-coding v5)

- Next.js 15 + TypeScript + Tailwind v4 + shadcn/ui
- AI team: 9 agents (2 opus + 7 sonnet)
- Context Engineering: plan.md 외부 메모리, /save 명령어
- Hooks: auto-format, auto-commit, branch protection, secret scan
- Rules: frontend, backend, testing, security, supabase
- Commands: /start, /done, /review, /learn, /new-task, /save
- cc-sdd: spec-driven development
- CI/CD: GitHub Actions"

if command -v gh &> /dev/null && [ -n "$GITHUB_USER" ]; then
  gh repo create "$PROJECT_NAME" --private --source=. --push
  echo "✅ GitHub: https://github.com/$GITHUB_USER/$PROJECT_NAME"
else
  echo "⚠️ 나중에: gh auth login → gh repo create $PROJECT_NAME --private --source=. --push"
fi

# ============================================================
# 완료
# ============================================================
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅ 프로젝트 초기화 완료! (v5 — Context Engineering 포함)"
echo ""
echo "🚀 다음 단계:"
echo "  1. pnpm dev              ← 브라우저에서 localhost:3000 확인"
echo "  2. claude                ← Claude Code 시작"
echo "  3. Skills 설치 (Claude Code 안에서):"
echo "     npx skills add vercel-labs/agent-skills --skill frontend-design"
echo "  4. /start                ← 세션 시작 (plan.md 자동 로드)"
echo ""
echo "📋 .env.local에 Supabase 키 입력도 잊지 마세요."
echo ""
echo "💡 새로 추가된 기능:"
echo "  /save   — 작업 맥락을 plan.md에 저장 (세션 리셋 전에!)"
echo "  plan.md — /compact, /clear 후에도 살아남는 외부 메모리"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
